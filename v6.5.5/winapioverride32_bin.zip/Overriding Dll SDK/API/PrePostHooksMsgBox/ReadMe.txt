Goal : Discover possibility of Pre and Post hooks (multiple of pre and post hooks available for a single api inside differents overriding dlls)

--------------------------------------------------------------------
How to use :
1) Hook target with WinApiOverride
2) load the overriding dll with WinApiOverride
That's all