Goal : Hide WinApiOverride process from target
	Notice : works with windows task manager and sysinternal process explorer

--------------------------------------------------------------------
How to use :
1) Hook target with WinApiOverride
2) load the overriding dll with WinApiOverride
That's all