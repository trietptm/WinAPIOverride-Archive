/*
Copyright (C) 2004-2018 Jacquelin POTIER <jacquelin.potier@free.fr>
Dynamic aspect ratio code Copyright (C) 2004-2018 Jacquelin POTIER <jacquelin.potier@free.fr>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#pragma once

enum tagProcessorType
{
    ProcessorType_X86 = 0, // default one
    ProcessorType_AMD64,

    ProcessorType_UNDEFINED
};

enum tagEndianness
{
    Endianness_LITTLE=0,
    Endianness_BIG,

    Endianness_UNDEFINED
};

// use intrinsic instead of macro
#pragma intrinsic(_byteswap_ushort,_byteswap_ulong,_byteswap_uint64)
#define BYTE_SWAP_UINT16 _byteswap_ushort
#define BYTE_SWAP_UINT32 _byteswap_ulong
#define BYTE_SWAP_UINT64 _byteswap_uint64
//#define BYTE_SWAP_UINT16(x) ((((x) >> 8) & 0xff) | (((x) & 0xff) << 8))
//#define BYTE_SWAP_UINT32(x) (   (((x) & 0xff000000) >> 24) \
//                                | (((x) & 0x00ff0000) >>  8) \
//                                | (((x) & 0x0000ff00) <<  8) \
//                                | (((x) & 0x000000ff) << 24) \
//                              )
//# define BYTE_SWAP_UINT64(x) (  (((x) & 0xff00000000000000ull) >> 56) \
//                                | (((x) & 0x00ff000000000000ull) >> 40) \
//                                | (((x) & 0x0000ff0000000000ull) >> 24) \
//                                | (((x) & 0x000000ff00000000ull) >> 8)  \
//                                | (((x) & 0x00000000ff000000ull) << 8)  \
//                                | (((x) & 0x0000000000ff0000ull) << 24) \
//                                | (((x) & 0x000000000000ff00ull) << 40) \
//                                | (((x) & 0x00000000000000ffull) << 56) \
//                                )


#define CURRENT_PROCESSOR_ENDIANNESS Endianness_LITTLE

#define POTENTIAL_SWAP16(x,RequiredEndianness) ((RequiredEndianness==CURRENT_PROCESSOR_ENDIANNESS) ? (UINT16)x:BYTE_SWAP_UINT16((UINT16)x))
#define POTENTIAL_SWAP32(x,RequiredEndianness) ((RequiredEndianness==CURRENT_PROCESSOR_ENDIANNESS) ? (UINT32)x:BYTE_SWAP_UINT32((UINT32)x))
#define POTENTIAL_SWAP64(x,RequiredEndianness) ((RequiredEndianness==CURRENT_PROCESSOR_ENDIANNESS) ? (UINT64)x:BYTE_SWAP_UINT64((UINT64)x))

FORCEINLINE float POTENTIAL_SWAP_FLOAT  (float x,tagEndianness RequiredEndianness) 
{ 
    if (RequiredEndianness==CURRENT_PROCESSOR_ENDIANNESS) 
        return x; 
    else 
    {
        UINT32 u32=BYTE_SWAP_UINT32( * ((UINT32*)&x)); 
        return *(float*)&u32;
    } 
}
FORCEINLINE double POTENTIAL_SWAP_DOUBLE(double x,tagEndianness RequiredEndianness) 
{ 
    if (RequiredEndianness==CURRENT_PROCESSOR_ENDIANNESS) 
        return x; 
    else 
    {
        UINT64 u64=BYTE_SWAP_UINT64( * ((UINT64*)&x)); 
        return *(double*)&u64;
    } 
}

#ifdef _WIN64
    #define POTENTIAL_SWAP_SIZE_T POTENTIAL_SWAP64
#else
    #define POTENTIAL_SWAP_SIZE_T POTENTIAL_SWAP32
#endif

#define POTENTIAL_SWAP_POINTER(ProcessorType,x,RequiredEndianness) ( (ProcessorType==ProcessorType_X86) ? POTENTIAL_SWAP32(x,RequiredEndianness):POTENTIAL_SWAP64(x,RequiredEndianness) )

FORCEINLINE const TCHAR* GetProcessorTypeString(tagProcessorType ProcessorType)
{
    switch (ProcessorType)
    {
    case ProcessorType_AMD64:
#ifdef _WIN64
    default:
#endif
        return TEXT("64 bits");
    case ProcessorType_X86:
#ifndef _WIN64
    default:
#endif
        return TEXT("32 bits");
    }
}

#ifndef GetCurrentProcessorType
#ifdef _WIN64
#define GetCurrentProcessorType() (ProcessorType_AMD64)
#else
#define GetCurrentProcessorType() (ProcessorType_X86)
#endif

#endif