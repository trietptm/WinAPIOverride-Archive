/*
Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>
Dynamic aspect ratio code Copyright (C) 2004 Jacquelin POTIER <jacquelin.potier@free.fr>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#pragma once

#pragma pack(push)
#pragma pack(8)

#define APIOVERRIDE_DEFINES_PATH _T("UserDefines\\")
#define APIOVERRIDE_USER_TYPES_PATH _T("UserTypes\\")

#define PARAMETER_LOG_INFOS_PARAM_NAME_MAX_SIZE 40


///////////////////////////////////
// parameter type extended flags //
///////////////////////////////////
#define EXTENDED_TYPE_FLAG_NET_SINGLE_DIM_ARRAY     0x80000000 // used internally by injected dll only
#define EXTENDED_TYPE_FLAG_NET_MULTIPLE_DIM_ARRAY   0x40000000 // used internally by injected dll only
#define EXTENDED_TYPE_FLAG_HAS_ASSOCIATED_DEFINE_VALUES_FILE 0x20000000 // used by winapioverride and injected dll
#define EXTENDED_TYPE_FLAG_HAS_ASSOCIATED_USER_DATA_TYPE_FILE 0x10000000 // used by winapioverride and injected dll
#define EXTENDED_TYPE_FLAG_PARAM_IS_LARGE_RETURN    0x08000000 // used internally by injected dll only
#define EXTENDED_TYPE_FLAG_PARAM_STACK_LARGE_RETURN 0x04000000 // force large return to be passed on stack used internally by injected dll only
#define EXTENDED_TYPE_FLAG_POINTER_REFERENCE        0x02000000 // used by winapioverride and injected dll 
#define EXTENDED_TYPE_FLAG_X86_64BITS_RETURN        0x01000000 // x86 64bit return
//#define EXTENDED_TYPE_FLAG_                         0x008000000 // SIMPLE_TYPE_FLAG_MASK + EXTENDED_TYPE_FLAG_MASK to be changed for next EXTENDED_TYPE_FLAG_
#define EXTENDED_TYPE_FLAG_MASK                     0xFF000000 // (~SIMPLE_TYPE_FLAG_MASK)
#define SIMPLE_TYPE_FLAG_MASK                       0x00FFFFFF  // winapioverrride enum type mask (allow to use unused PARAMETER_INFOS.dwType first bytes as extended informations)
#define EXTENDED_TYPE_SetNewSimpleType(Var,NewSimpleType)( Var = ( (Var&EXTENDED_TYPE_FLAG_MASK)|NewSimpleType) ) // keep extended type, but change simple type



typedef struct tagParameterLogInfos
    // /!\ WARNING IF MODIFIED, tagParameterLogInfos32 in SupportedParameters.h must be modified
{
    DWORD dwType;
    PBYTE Value;// if (dwSizeOfPointedValue >0 )
    // {
    //      Value = pointer value // data value is in pbValue
    // }
    // else
    // {
    //      if (dwSizeOfData < REGISTER_BYTE_SIZE) // direct data value
    //          {Value = value of parameter}
    //      else 
    //          {value is stored in pbValue and Value = 0}
    // }
    DWORD dwSizeOfData;// size of Data. If <=REGISTER_BYTE_SIZE param value is stored in Value (no memory allocation) else in pbValue 
    DWORD dwSizeOfPointedValue;// size of pbValue.
    TCHAR pszParameterName[PARAMETER_LOG_INFOS_PARAM_NAME_MAX_SIZE];
    BYTE* pbValue;// content of data if dwSizeOfData > REGISTER_BYTE_SIZE
    // content of pointer if dwSizeOfPointedData > 0
    // NULL if (dwSizeOfData <= REGISTER_BYTE_SIZE) && (dwSizeOfPointedData==0)
    TCHAR* pszDefineNamesFile; 
    TCHAR* pszUserDataTypeName;
}PARAMETER_LOG_INFOS,*PPARAMETER_LOG_INFOS;

#pragma pack(pop)