/*
Copyright (C) 2004-2018 Jacquelin POTIER <jacquelin.potier@free.fr>
Dynamic aspect ratio code Copyright (C) 2004-2018 Jacquelin POTIER <jacquelin.potier@free.fr>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#pragma once

#define API_OVERRIDE_DLL_SHORT_BASE_NAME _T("ApiOverride")

// dll  name
#define API_OVERRIDE_DLL_NAME32 _T("ApiOverride.dll")
#define HOOKNET_DLL_NAME32 _T("hooknet.dll")
#define INJECTLIB_DLL_NAME32 _T("InjLib.dll")

#define API_OVERRIDE_DLL_NAME64 _T("ApiOverride64.dll")
#define HOOKNET_DLL_NAME64 _T("hooknet64.dll")
#define INJECTLIB_DLL_NAME64 _T("InjLib64.dll")

#ifdef _WIN64
#define INJECTLIB_DLL_NAME INJECTLIB_DLL_NAME64
#define API_OVERRIDE_DLL_NAME API_OVERRIDE_DLL_NAME64
#define HOOKNET_DLL_NAME HOOKNET_DLL_NAME64
#else
#define INJECTLIB_DLL_NAME INJECTLIB_DLL_NAME32
#define API_OVERRIDE_DLL_NAME API_OVERRIDE_DLL_NAME32
#define HOOKNET_DLL_NAME HOOKNET_DLL_NAME32
#endif