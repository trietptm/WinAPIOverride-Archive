Goal : show that asm function can be monitored without affecting registers
	and that asm function can be override too
	Monitoring files show the breaking before and after api capabilities too,
	alowing you to act on registers

--------------------------------------------------------------------
How to use :
1) Hook target with WinApiOverride
2) load the monitoring file or overriding dll with WinApiOverride
That's all