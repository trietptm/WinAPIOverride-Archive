Goal : allow you to see how to have a callback called at each COM object creation

--------------------------------------------------------------------
How to use :
1) Launch the microsoft ActiveX Test Container (TstCon)
2) Hook TstCon.exe with WinApiOverride
3) Load overriding dll inside WinApiOverride
4) Create any control inside TstCon

