Goal : change MessageBox icon a text (if possible)
	Basic example to override an api

--------------------------------------------------------------------
How to use :
1) Hook target with WinApiOverride
2) load the overriding dll with WinApiOverride
That's all