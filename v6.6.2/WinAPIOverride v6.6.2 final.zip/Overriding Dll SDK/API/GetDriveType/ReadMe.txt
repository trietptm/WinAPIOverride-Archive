Goal : make believe that target is executing on CD drive
	Each time GetDriveType API is called it will always return CD value

--------------------------------------------------------------------
How to use :
1) Hook target with WinApiOverride
2) load the overriding dll with WinApiOverride
That's all